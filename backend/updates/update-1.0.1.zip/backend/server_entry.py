#!/usr/bin/env python3
"""
Demet Backend Server Entry Point
Lisans kontrolü + Uvicorn sunucu başlatma
Electron tarafından çağrılır
"""
import os
import sys
import time
from pathlib import Path

# PyInstaller uyumluluğu
if getattr(sys, 'frozen', False):
    BASE_DIR = Path(sys.executable).parent
    os.chdir(BASE_DIR)
    BUNDLE_DIR = Path(sys._MEIPASS) if hasattr(sys, '_MEIPASS') else BASE_DIR
else:
    BASE_DIR = Path(__file__).resolve().parent
    BUNDLE_DIR = BASE_DIR

sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BUNDLE_DIR))


def show_license_window():
    """Lisans aktivasyon penceresi (tkinter)."""
    import tkinter as tk
    from tkinter import messagebox
    from app.license import get_hwid, activate_license

    result_holder = {"result": None}

    root = tk.Tk()
    root.title("Demet — Lisans Aktivasyonu")
    root.geometry("600x400")
    root.resizable(False, False)
    root.configure(bg="#1a1a2e")

    # Ortala
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 300
    y = (root.winfo_screenheight() // 2) - 200
    root.geometry(f"+{x}+{y}")

    # Başlık
    tk.Label(
        root, text="🔐 Demet Lisans Aktivasyonu",
        font=("Segoe UI", 16, "bold"), fg="#e94560", bg="#1a1a2e",
    ).pack(pady=(25, 10))

    # HWID
    hwid_frame = tk.Frame(root, bg="#16213e", padx=15, pady=10)
    hwid_frame.pack(fill="x", padx=30, pady=(5, 15))

    tk.Label(
        hwid_frame, text="Bu Makinenin HWID'si:",
        font=("Segoe UI", 9), fg="#a0a0a0", bg="#16213e",
    ).pack(anchor="w")

    hwid = get_hwid()
    hwid_entry = tk.Entry(
        hwid_frame, font=("Consolas", 11), fg="#00d2ff", bg="#0f3460",
        relief="flat", readonlybackground="#0f3460",
    )
    hwid_entry.insert(0, hwid)
    hwid_entry.config(state="readonly")
    hwid_entry.pack(fill="x", pady=(3, 0))

    tk.Label(
        root,
        text="Bu HWID'yi yöneticinize gönderin, size lisans anahtarı verilecektir.",
        font=("Segoe UI", 9), fg="#a0a0a0", bg="#1a1a2e", wraplength=500,
    ).pack(pady=(0, 10))

    # Anahtar girişi
    tk.Label(
        root, text="Lisans Anahtarı:",
        font=("Segoe UI", 10, "bold"), fg="#ffffff", bg="#1a1a2e",
    ).pack(anchor="w", padx=30)

    key_text = tk.Text(
        root, height=4, font=("Consolas", 10),
        fg="#ffffff", bg="#0f3460", relief="flat",
        insertbackground="#ffffff",
    )
    key_text.pack(fill="x", padx=30, pady=(3, 15))

    status_label = tk.Label(
        root, text="", font=("Segoe UI", 9),
        fg="#a0a0a0", bg="#1a1a2e",
    )
    status_label.pack(pady=(5, 0))

    def on_activate():
        key = key_text.get("1.0", "end").strip()
        if not key:
            status_label.config(text="⚠️ Lisans anahtarı giriniz", fg="#ffcc00")
            return
        res = activate_license(key)
        if res["valid"]:
            result_holder["result"] = res
            messagebox.showinfo(
                "Başarılı",
                f"✅ Lisans aktive edildi!\n\nSahip: {res['owner']}\nKalan: {res['remaining_days']} gün",
            )
            root.destroy()
        else:
            status_label.config(text=f"❌ {res['error']}", fg="#ff4444")

    def on_exit():
        root.destroy()

    btn_frame = tk.Frame(root, bg="#1a1a2e")
    btn_frame.pack(fill="x", padx=30)

    tk.Button(
        btn_frame, text="✅ Aktive Et", font=("Segoe UI", 11, "bold"),
        fg="#ffffff", bg="#e94560", relief="flat", padx=20, pady=8,
        cursor="hand2", command=on_activate,
    ).pack(side="left")

    tk.Button(
        btn_frame, text="Çıkış", font=("Segoe UI", 10),
        fg="#a0a0a0", bg="#16213e", relief="flat", padx=15, pady=8,
        cursor="hand2", command=on_exit,
    ).pack(side="right")

    root.mainloop()
    return result_holder["result"]


def main():
    from app.license import verify_license

    # 1. Lisans kontrolü
    license_info = verify_license()

    if not license_info["valid"]:
        # Lisans penceresi göster
        license_info = show_license_window()
        if not license_info or not license_info.get("valid"):
            print("[Demet] Lisans aktive edilmedi. Çıkılıyor...")
            sys.exit(1)

    print(f"[Demet] Lisans OK — {license_info.get('owner', '')} ({license_info.get('remaining_days', 0)} gün)")

    # 2. Sunucuyu başlat
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="127.0.0.1",
        port=8000,
        log_level="warning",
    )


if __name__ == "__main__":
    main()
