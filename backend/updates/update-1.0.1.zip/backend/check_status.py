import requests, json
BASE = "http://localhost:8000/api"
auth = requests.post(f"{BASE}/auth/login", json={"username": "admin", "password": "admin123"})
token = auth.json()["access_token"]
headers = {"Authorization": f"Bearer {token}"}
accounts = requests.get(f"{BASE}/accounts", headers=headers).json()
active = [a for a in accounts if a.get("is_active")]
print(f"Toplam: {len(accounts)} hesap, Aktif: {len(active)}")
for a in accounts:
    status = "AKTIF" if a.get("is_active") else "PASIF"
    uname = a["username"]
    aid = a["id"]
    print(f"  {status} @{uname} (ID={aid})")
