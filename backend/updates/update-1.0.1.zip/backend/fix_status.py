"""Revert status to uppercase."""
import sqlite3
conn = sqlite3.connect('demet.db')
c = conn.cursor()
c.execute("UPDATE posts SET status='DRAFT' WHERE status='draft'")
c.execute("UPDATE posts SET status='SCHEDULED' WHERE status='scheduled'")
c.execute("UPDATE posts SET status='PUBLISHING' WHERE status='publishing'")
c.execute("UPDATE posts SET status='PUBLISHED' WHERE status='published'")
c.execute("UPDATE posts SET status='FAILED' WHERE status='failed'")
conn.commit()
for r in c.execute("SELECT id, status FROM posts").fetchall():
    print(f"  #{r[0]}: {r[1]}")
conn.close()
print("Done!")
