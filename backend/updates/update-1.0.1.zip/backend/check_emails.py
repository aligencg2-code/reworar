"""Check email credentials stored in DB — write to file."""
import sqlite3, os

db_path = os.path.join(os.path.dirname(__file__), "demet.db")
conn = sqlite3.connect(db_path)
cur = conn.cursor()

cur.execute("PRAGMA table_info(accounts)")
cols = cur.fetchall()
col_names = [c[1] for c in cols]

with open("email_check_result.txt", "w", encoding="utf-8") as f:
    f.write("All columns:\n")
    for c in cols:
        f.write(f"  {c[1]} ({c[2]})\n")
    f.write("\n")

    # Check email-related columns
    email_cols = [c for c in col_names if "email" in c.lower()]
    f.write(f"Email columns: {email_cols}\n\n")

    # Get first 3 accounts
    cur.execute(f"SELECT * FROM accounts LIMIT 3")
    rows = cur.fetchall()
    for row in rows:
        f.write("--- Account ---\n")
        for name, val in zip(col_names, row):
            val_str = str(val)[:100] if val else "NULL"
            f.write(f"  {name}: {val_str}\n")
        f.write("\n")

    # Count how many have email_addr
    cur.execute("SELECT COUNT(*) FROM accounts WHERE email_addr IS NOT NULL AND email_addr != ''")
    count_email = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM accounts WHERE email_password_encrypted IS NOT NULL AND email_password_encrypted != ''")
    count_email_pass = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM accounts")
    total = cur.fetchone()[0]
    
    f.write(f"\nTotal accounts: {total}\n")
    f.write(f"With email_addr: {count_email}\n")
    f.write(f"With email_password: {count_email_pass}\n")

conn.close()
print("Written to email_check_result.txt")
