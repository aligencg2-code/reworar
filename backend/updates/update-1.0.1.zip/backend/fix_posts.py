"""Mevcut medyaları postlara bağla ve yayınlama testi yap."""
import sqlite3
import os
import json
from pathlib import Path

conn = sqlite3.connect('demet.db')
c = conn.cursor()

# 1) Mevcut durum
print("=== MEVCUT DURUM ===")
posts = c.execute("SELECT id, status, account_id, media_type, caption FROM posts").fetchall()
for p in posts:
    print(f"  Post #{p[0]}: status={p[1]}, account={p[2]}, type={p[3]}, caption={p[4]}")

media = c.execute("SELECT id, filename, file_path, account_id FROM media_files").fetchall()
for m in media:
    print(f"  Media #{m[0]}: filename={m[1]}, exists={os.path.exists(m[2])}")

links = c.execute("SELECT * FROM post_media").fetchall()
print(f"  post_media rows: {len(links)}")

# 2) Medyaları ilk posta bağla
if len(links) == 0 and len(posts) > 0 and len(media) > 0:
    post_id = posts[0][0]  # İlk post
    print(f"\n=== Medyaları Post #{post_id}'ye bağlıyorum ===")
    for i, m in enumerate(media):
        c.execute(
            "INSERT INTO post_media (post_id, media_id, position) VALUES (?, ?, ?)",
            (post_id, m[0], i)
        )
        print(f"  ✅ Media #{m[0]} -> Post #{post_id} (position={i})")
    
    # Post durumunu DRAFT yap (tekrar yayınlanabilsin)
    c.execute("UPDATE posts SET status='DRAFT' WHERE id=?", (post_id,))
    print(f"  ✅ Post #{post_id} status -> DRAFT")
    
    conn.commit()
    print("  ✅ Commit başarılı")
else:
    print("  ⚠️ Bağlama gerekmedi veya veri yok")

# 3) Session kontrol
print("\n=== SESSION KONTROL ===")
sessions_dir = Path("sessions")
if sessions_dir.exists():
    for f in sessions_dir.iterdir():
        if f.suffix == '.json':
            try:
                data = json.loads(f.read_text())
                auth = data.get("authorization_data", {})
                user_id = auth.get("ds_user_id", "?")
                print(f"  ✅ {f.name} -> user_id={user_id}")
            except Exception as e:
                print(f"  ❌ {f.name} -> HATA: {e}")

# 4) Account bilgisi
account_id = posts[0][2] if posts else None
if account_id:
    acc = c.execute("SELECT id, username, proxy_url FROM accounts WHERE id=?", (account_id,)).fetchone()
    if acc:
        print(f"\n=== HESAP ===")
        print(f"  id={acc[0]}, username={acc[1]}, proxy={acc[2]}")
        
        # Session var mı?
        session_file = sessions_dir / f"{acc[1]}.json"
        print(f"  Session: {session_file} -> exists={session_file.exists()}")

# 5) Doğrulama
print("\n=== DOĞRULAMA ===")
links = c.execute("SELECT * FROM post_media").fetchall()
print(f"  post_media rows: {len(links)}")
for l in links:
    print(f"  post_id={l[1]}, media_id={l[2]}, position={l[3]}")

conn.close()
