"""DB structure checker."""
import sqlite3

conn = sqlite3.connect('demet.db')
c = conn.cursor()

# media_files table columns
print("=== media_files columns ===")
for row in c.execute("PRAGMA table_info(media_files)"):
    print(f"  {row}")

print("\n=== media_files data ===")
for row in c.execute("SELECT * FROM media_files LIMIT 5"):
    print(f"  {row}")

print("\n=== post_media columns ===")
for row in c.execute("PRAGMA table_info(post_media)"):
    print(f"  {row}")

print("\n=== post_media data ===")
for row in c.execute("SELECT * FROM post_media"):
    print(f"  {row}")

print("\n=== posts columns ===")
for row in c.execute("PRAGMA table_info(posts)"):
    print(f"  {row}")

print("\n=== sessions dir ===")
import os
sessions = os.listdir('sessions') if os.path.exists('sessions') else []
print(f"  Files: {sessions}")

conn.close()
