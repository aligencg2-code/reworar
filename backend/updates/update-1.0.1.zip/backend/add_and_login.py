"""Import 6 accounts and login them directly."""
import requests, json, time

BASE = "http://localhost:8000/api"

# 1. Auth
auth = requests.post(f"{BASE}/auth/login", json={"username": "admin", "password": "admin123"})
token = auth.json()["access_token"]
headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
print(f"✅ Auth OK\n")

# 2. Import accounts
accounts_text = """cerenmoney8:Fanefane42
elizasuadiyemasaj:asil1965
onlinevipdemet:191907
bade_atasehir:cansu191907
suderich6:Fanefane42
ahuist3:Fanefane42"""

print("📥 Hesaplar ekleniyor...")
r = requests.post(f"{BASE}/accounts/bulk-import", headers=headers, json={
    "accounts_text": accounts_text,
    "default_proxy": None,
})
import_result = r.json()
print(f"Import: {json.dumps(import_result, indent=2, ensure_ascii=False)}\n")

# 3. Get all accounts to find the new ones
accounts = requests.get(f"{BASE}/accounts", headers=headers).json()
new_usernames = ["cerenmoney8", "elizasuadiyemasaj", "onlinevipdemet", "bade_atasehir", "suderich6", "ahuist3"]
new_accounts = [a for a in accounts if a["username"] in new_usernames]
print(f"🔍 Bulunan yeni hesaplar: {len(new_accounts)}\n")

# 4. Login each one
for acc in new_accounts:
    acc_id = acc["id"]
    username = acc["username"]
    print(f"🔑 @{username} (ID={acc_id}) giriş deneniyor...", end=" ", flush=True)
    
    try:
        r = requests.post(f"{BASE}/accounts/login-single", headers=headers, json={"account_id": acc_id}, timeout=120)
        result = r.json()
        if result.get("success"):
            print(f"✅ BAŞARILI!")
        elif result.get("needs_code"):
            print(f"📧 Doğrulama kodu gerekiyor: {result.get('message', '')[:80]}")
        else:
            print(f"❌ {result.get('message', 'Bilinmeyen hata')[:80]}")
    except Exception as e:
        print(f"❌ Hata: {e}")
    
    # Hesaplar arası bekleme
    time.sleep(3)

print("\n✅ Tamamlandı!")
