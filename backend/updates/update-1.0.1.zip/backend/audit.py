"""Comprehensive system audit v2 — verify all fixes."""
import requests
import json

BASE = "http://127.0.0.1:8000/api"

# Login
resp = requests.post(f"{BASE}/auth/login", json={"username": "admin", "password": "admin123"})
print(f"1. LOGIN: {resp.status_code}")
if resp.status_code != 200:
    print(f"   FATAL: {resp.text}")
    exit(1)
data = resp.json()
token = data["access_token"]
role = data.get("user", {}).get("role")
print(f"   Role: {role}")
H = {"Authorization": f"Bearer {token}"}

# Dashboard
print("\n=== DASHBOARD ===")
r = requests.get(f"{BASE}/dashboard/stats", headers=H)
print(f"2. Stats: {r.status_code}")
if r.status_code == 200:
    d = r.json()
    print(f"   accounts={d.get('total_accounts')}, active={d.get('active_accounts')}")
    print(f"   posts_today={d.get('posts_today')}, scheduled={d.get('scheduled_posts')}")
    print(f"   media={d.get('total_media')}, failed_week={d.get('failed_posts_week')}")
else:
    print(f"   ERROR: {r.text[:200]}")

r = requests.get(f"{BASE}/dashboard/activity?limit=5", headers=H)
print(f"3. Activity: {r.status_code}")

# Accounts
print("\n=== ACCOUNTS ===")
r = requests.get(f"{BASE}/accounts", headers=H)
print(f"4. Accounts: {r.status_code} ({len(r.json())} items)")

# Posts
print("\n=== POSTS ===")
r = requests.get(f"{BASE}/posts", headers=H)
print(f"5. Posts: {r.status_code}")
if r.status_code == 200:
    d = r.json()
    for p in d.get("posts", []):
        print(f"   #{p['id']}: status={p['status']}, media_type={p['media_type']}, media={p.get('media_count')}")
else:
    print(f"   ERROR: {r.text[:200]}")

# Calendar
print("\n=== CALENDAR ===")
r = requests.get(f"{BASE}/posts/calendar?month=2&year=2026", headers=H)
print(f"6. Calendar: {r.status_code}")
if r.status_code == 200:
    d = r.json()
    for day, items in d.get("days", {}).items():
        for item in items:
            print(f"   Day {day}: #{item['id']} status={item['status']} type={item['media_type']}")

# Media
print("\n=== MEDIA ===")
r = requests.get(f"{BASE}/media", headers=H)
print(f"7. Media: {r.status_code}")
if r.status_code == 200:
    d = r.json()
    print(f"   Total: {d.get('total')}")
    print(f"   Counts: {d.get('counts')}")
    for m in d.get("items", []):
        print(f"   #{m['id']}: type={m['media_type']}, file_url={m.get('file_url')}")
else:
    print(f"   ERROR: {r.text[:200]}")

# Messages
print("\n=== MESSAGES ===")
r = requests.get(f"{BASE}/messages/templates", headers=H)
print(f"8. Templates: {r.status_code} ({len(r.json()) if r.status_code == 200 else 'ERR'} items)")

r = requests.get(f"{BASE}/messages/auto-reply", headers=H)
print(f"9. Auto-Reply: {r.status_code}")

# Hashtags
print("\n=== HASHTAGS ===")
r = requests.get(f"{BASE}/hashtags", headers=H)
print(f"10. Hashtags: {r.status_code}")

# Settings
print("\n=== SETTINGS ===")
r = requests.get(f"{BASE}/settings", headers=H)
print(f"11. Settings: {r.status_code}")

# Appeals (uses /summary)
print("\n=== APPEALS ===")
r = requests.get(f"{BASE}/appeals/summary", headers=H)
print(f"12. Summary: {r.status_code}")
if r.status_code == 200:
    d = r.json()
    print(f"   Total={d.get('total')}, Active={d.get('active')}, Restricted={d.get('restricted')}")

# Profiles (uses /all)
print("\n=== PROFILES ===")
r = requests.get(f"{BASE}/profiles/all", headers=H)
print(f"13. Profiles: {r.status_code}")

# Backups
print("\n=== BACKUPS ===")
r = requests.get(f"{BASE}/dashboard/backups", headers=H)
print(f"14. Backups: {r.status_code}")

# Publish test
print("\n=== PUBLISH TEST ===")
r = requests.post(f"{BASE}/posts/1/publish", headers=H)
print(f"15. Publish: {r.status_code}")
print(f"    Body: {r.text[:200]}")

print("\n=== ALL TESTS DONE ===")
