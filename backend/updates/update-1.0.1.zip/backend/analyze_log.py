"""Write login analysis to file for reading."""
with open("login_debug.log", "r", encoding="utf-8") as f:
    lines = f.readlines()

recent = [l.rstrip() for l in lines if l.startswith("2026-02-17 20:")]

out = []
keywords = [
    "giriş deneniyor", "giriş başarılı", "session ile giriş",
    "BadPassword", "hata", "challenge", "checkpoint",
    "IMAP", "proxy", "rate limit", "reCAPTCHA",
    "beklenmeyen", "başarısız", "engelle", "feedback",
    "PleaseWait", "Sentry", "block", "temporary",
    "session expired", "session yüklenemedi",
    "PROXY'SİZ", "proxy'siz", "Challenge state",
    "şifre", "kimlik", "invalid"
]

for line in recent:
    if any(k.lower() in line.lower() for k in keywords):
        out.append(line[:250])

with open("login_analysis.txt", "w", encoding="utf-8") as f:
    f.write(f"Total recent lines: {len(recent)}\n")
    f.write(f"Filtered key events: {len(out)}\n\n")
    for o in out:
        f.write(o + "\n")

print(f"Written {len(out)} events to login_analysis.txt")
