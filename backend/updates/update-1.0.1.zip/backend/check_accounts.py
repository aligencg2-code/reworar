"""Check which accounts have passwords and their login state."""
import sqlite3
c = sqlite3.connect('demet.db')
rows = c.execute("""
    SELECT id, username, proxy_url, session_valid, account_status,
           email_encrypted IS NOT NULL as has_email,
           email_password_encrypted IS NOT NULL as has_email_pass,
           two_factor_seed IS NOT NULL as has_2fa,
           password_encrypted IS NOT NULL as has_pass
    FROM accounts
    WHERE password_encrypted IS NOT NULL
    LIMIT 10
""").fetchall()
for r in rows:
    proxy_str = str(r[2])[:40] if r[2] else "NONE"
    print(f"ID={r[0]} @{r[1]:<25s} proxy={proxy_str:<42s} valid={r[3]} status={r[4]} email={r[5]} email_pass={r[6]} 2fa={r[7]}")
total = c.execute("SELECT count(*) FROM accounts WHERE password_encrypted IS NOT NULL").fetchone()[0]
print(f"\nTotal with password: {total}")
