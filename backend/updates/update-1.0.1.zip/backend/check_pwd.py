import sqlite3
from app.utils.encryption import decrypt_token

db = sqlite3.connect("demet.db")
rows = db.execute(
    "SELECT id, username, password_encrypted FROM accounts WHERE username IN ('vipexclusive.ceren','vipexclusive.seyda','vip.ariaa','elite.lina34')"
).fetchall()
for r in rows:
    pwd = decrypt_token(r[2])
    print(f"ID={r[0]} @{r[1]} password={pwd}")
db.close()
