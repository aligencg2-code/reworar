# main.py — uvicorn giriş noktası
# uvicorn main:app --reload komutu bu dosyayı kullanır
from app.main import app  # noqa: F401
