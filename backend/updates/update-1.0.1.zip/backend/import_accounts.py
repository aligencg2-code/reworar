"""Eski hesaplari sil, yeni Gmail/Hotmail hesaplari ekle.
Format: email:email_password:ig_username:ig_password:birth_year
"""
import requests
import json

BASE = "http://127.0.0.1:8000/api"

# Login
r = requests.post(f"{BASE}/auth/login", json={"username": "admin", "password": "admin123"})
token = r.json()["access_token"]
h = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

# 1) Eski hesaplari sil
print("=== Eski hesaplar siliniyor ===")
r = requests.get(f"{BASE}/accounts/", headers=h)
old_accounts = r.json()
print(f"Mevcut: {len(old_accounts)} hesap")
for acc in old_accounts:
    aid = acc["id"]
    r2 = requests.delete(f"{BASE}/accounts/{aid}", headers=h)
    print(f"  Silindi: #{aid} @{acc['username']}")

# 2) Yeni hesaplari haziirla
# Kullanici formati: email:email_password:ig_username:ig_password:birth_year
# Import formati: ig_username:ig_password:email:email_password
raw = """agustingreenwa@gmail.com:yunus128:elif.massageonline:Fanefane42:2014
kathrynmontelo@gmail.com:gunum128:canan.massageonline:Fanefane42:2014
emily65x3@gmail.com:tamba959:suzan.massageonline:Fanefane42:2014
unggoynahiphop@gmail.com:gunumb1289:ceylan.massageonline:Fanefane42:2014
larrydiego93@gmail.com:gunum128:dilan.massageonline:Fanefane42:2014
simbacortese@gmail.com:gynumm128:serpil.massageonline:Fanefane42:2014
lylecorreia99@gmail.com:gunumv128:leyla.massageonline:Fanefane42:2014
mykedmychael@gmail.com:bunumm128:merve.massageonline:Fanefane42:2014
usofoxy@gmail.com:guyub128:umran.massageonline:Fanefane42:2014
nooofalasiri@gmail.com:gunu1281:jale.massageonline:Fanefane42:2014
sekakomljen1@gmail.com:suna1992:selma.massageonline:Fanefane42:2014
earleancadwall@gmail.com:susam1992:asel.massageonline:Fanefane42:2014
prettaincomoda@gmail.com:suna1288:pelin.massageonline:Fanefane42:2014
robtleet@gmail.com:esra1288:reyhan.massageonline:Fanefane42:2014
maryanngravley@gmail.com:susam1288:meryem.massageonline:Fanefane42:2014
maciemaston@gmail.com:osuhz1288:ferda.massageonline:Fanefane42:2014
jerroldstokely@gmail.com:asum1288:cansu.massageonline:Fanefane42:2014
yolondalally@gmail.com:susam1289:yeliz.massageonline:Fanefane42:2014
maryahowser@gmail.com:baran1992:asuman.massageonline:Fanefane42:2014
rayvenhere@gmail.com:susa1992:basak.massageonline:Fanefane42:2014
vehlijatt12@gmail.com:suna1632:tulay.massageonline:Fanefane42:2014
tyrahmuff@gmail.com:suna1633:pinar.massageonline:Fanefane42:2014
sharitaduffiel@gmail.com:esem1288:seher.massageonline:Fanefane42:2014
chirlenehugo@gmail.com:huso1288:emel.massageonline:Fanefane42:2014
ronibenzvi367@gmail.com:suna1288:irem.massageonline:Fanefane42:2014
rhonahickey@gmail.com:sese1992:gulay.massageonline:Fanefane42:2014
yisraelchen350@gmail.com:sunam1992:nuray.massageonline:Fanefane42:2014
rj1104567@gmail.com:sese1281:rabia.massageonline:Fanefane42:2014
guysegel880@gmail.com:sinem1288:gulse.massageonline:Fanefane42:2014
puwumuab@gmail.com:gubunn1289:perihan.massageonline:Fanefane42:2013
ubxcols3wc766uqw@hotmail.com:RPTRgTN6Ce:aydan.massageonline:Fanefane42:2015
jomakhalawi@gmail.com:guyunn128:janset.massageonline:Fanefane42:2013
iaoabcxz@gmail.com:sena1992:sila.massageonline:Fanefane42:2013
deyoiwoo@gmail.com:guyubb128:derya.massageonline:Fanefane42:2013
xlsmyyuy@gmail.com:sedef1288:sevcan.massageonline:Fanefane42:2013
aloooooosh2722@gmail.com:sese1992:azra.massageonline:Fanefane42:2013
qzmuziuy@gmail.com:susam1992:gamze.massageonline:Fanefane42:2013
chialing5511@gmail.com:sesem1288:sunay.massageonline:Fanefane42:2013
cookiewhealon@gmail.com:wussa128:naz.massageonline:Fanefane42:2013
thefooobabes@gmail.com:senem1288:feride.massageonline:Fanefane42:2013
kxoaapii@gmail.com:sese1288:julide.massageonline:Fanefane42:2013
6663zf@gmail.com:zeytin128:nazan.massageonline:Fanefane42:2013
vaawwuab@gmail.com:susam128:kubra.massageonline:Fanefane42:2013
phfrjbg5df200ahh@hotmail.com:OScCXIst28:nesrin.massageonline:Fanefane43:2015
xlwxeyo5qa095xad@hotmail.com:XVXngT3Cb8:yusra.massageonline:Fanefane43:2015
yhiojpc4wg108vrb@hotmail.com:ONiZDoERou:sultan.massageonline:Fanefane43:2015
dakdolh0mh663kii@hotmail.com:DXhp5jGftC:alinda.massageonline:Fanefane43:2015
srzvvvs9wm357ijs@hotmail.com:KEACWBRlcw:ceyda.massageonline:Fanefane43:2015
iyuagca5zb561eik@hotmail.com:LWvOmuEKEX:cisem.massageonline:Fanefane43:2015
pgqhfau0ga901yoc@hotmail.com:GJOzVzKFzS:nazli.massageonline:Fanefane43:2015
vkopcxm5go139fpw@hotmail.com:BRLrDI70xa:burcu.massageonline:Fanefane42:2015
a0cispe9oh396azf@hotmail.com:RHznk09VTb:sevdanur.massageonline:Fanefane42:2015
fiswmwm7ra711pos@hotmail.com:ZK9eUkYDma:duygu.massageonline:Fanefane42:2015
jmfiahb9js204fmd@hotmail.com:VV7LCq9QxI:ayca.massageonline:Fanefane44:2015
g5wxgjb8qc158ira@hotmail.com:QFQNQlro04:eva.massageonline:Fanefane42:2015
toxuygj1rw081xcd@hotmail.com:NRLbYGIVij:sinemay.massageonline:Fanefane44:2015
gefowwb7tt550owt@hotmail.com:UBunmTVmzI:birce.massageonline:Fanefane42:2015
kdhvahm1of474dky@hotmail.com:OC6maSxOLR:fulya.massageonline:Fanefane43:2015
dhqijtb4jj332kdo@hotmail.com:SEa4duU9oJ:demet.massageonline:Fanefane43:2015
dzsgvky7ji991kqd@hotmail.com:MYcUbTlMMF:buket.massageonline:Fanefane42:2013
upxmrbx4ii783ftf@hotmail.com:WCESpjWL74:gulnaz.massageonline:Fanefane43:2015"""

# Format cevirme: email:email_pw:ig_user:ig_pw:year -> ig_user:ig_pw:email:email_pw
converted_lines = []
for line in raw.strip().split("\n"):
    parts = line.strip().split(":")
    if len(parts) != 5:
        print(f"  HATALI: {line[:50]}")
        continue
    email, email_pw, ig_user, ig_pw, _year = parts
    # Import formati: ig_username:ig_password:email:email_password
    converted_lines.append(f"{ig_user}:{ig_pw}:{email}:{email_pw}")

accounts_text = "\n".join(converted_lines)
print(f"\n=== {len(converted_lines)} hesap ekleniyor ===")

r = requests.post(f"{BASE}/accounts/bulk-import", headers=h, json={"accounts_text": accounts_text})
print(f"Status: {r.status_code}")
result = r.json()
print(json.dumps(result, indent=2, ensure_ascii=False))

# 3) Kontrol
print("\n=== DB kontrol ===")
r = requests.get(f"{BASE}/accounts/", headers=h)
accounts = r.json()
print(f"Toplam: {len(accounts)} hesap")

gmail_count = sum(1 for a in accounts if "@gmail" in (a.get("email") or ""))
hotmail_count = sum(1 for a in accounts if "@hotmail" in (a.get("email") or ""))
print(f"Gmail: {gmail_count} | Hotmail: {hotmail_count}")

for acc in accounts[:5]:
    print(f"  #{acc['id']} @{acc['username']} | {acc.get('email', 'N/A')}")
if len(accounts) > 5:
    print(f"  ... ve {len(accounts)-5} hesap daha")
